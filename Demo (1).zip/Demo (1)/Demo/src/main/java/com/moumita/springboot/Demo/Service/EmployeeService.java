package com.moumita.springboot.Demo.Service;

import java.util.List;

import com.moumita.springboot.Demo.Employee;

public interface EmployeeService {
	void createEmployee(Employee e);
	public List<Employee> getEmployee();
}
