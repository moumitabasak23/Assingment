package com.moumita.springboot.Demo.Repository;



import java.util.List;

import com.moumita.springboot.Demo.Employee;

public interface EmployeeRepository {
	public void createEmployee(Employee e);
	public List<Employee> getEmployee();
	
}
