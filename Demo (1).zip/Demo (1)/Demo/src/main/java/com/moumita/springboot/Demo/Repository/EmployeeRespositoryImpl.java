package com.moumita.springboot.Demo.Repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.moumita.springboot.Demo.Employee;



@Repository
public class EmployeeRespositoryImpl implements EmployeeRepository {

	@Autowired
	private EntityManager entityManager;
	

	@Override
	public List<Employee> getEmployee()
	{
		Session currentSession=entityManager.unwrap(Session.class);
		Query<Employee> query=currentSession.createQuery("from  Employee",Employee.class);
		List<Employee> list=query.getResultList();
		return list;
	}

	@Override
	public void createEmployee(Employee e) {
		Session currentSession=entityManager.unwrap(Session.class);
		 currentSession.save(e);
		
		
	}

}
