package com.moumita.springboot.Demo.Controller;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.moumita.springboot.Demo.Employee;
import com.moumita.springboot.Demo.Service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	@GetMapping(path="/employee",produces=MediaType.APPLICATION_XML_VALUE)
	public List<Employee> getEmployee(){
		return employeeService.getEmployee();
	}
	
	@PostMapping(path="/employee")
			
	public Employee createEmployee(@RequestBody Employee  e) {
	 employeeService.createEmployee(e);
	return e;
	}
}
