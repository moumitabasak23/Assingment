package com.moumita.springboot.Demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.moumita.springboot.Demo.Employee;
import com.moumita.springboot.Demo.Repository.EmployeeRepository;



@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	@Autowired
	 private EmployeeRepository repo;
	
	@Transactional
	@Override
	public void createEmployee(Employee e) {
		repo.createEmployee(e);
	}
	
	@Transactional
	@Override
	public List<Employee> getEmployee(){
		return repo.getEmployee();
	}
}
