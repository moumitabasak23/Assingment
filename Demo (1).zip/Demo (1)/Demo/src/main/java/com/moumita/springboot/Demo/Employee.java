package com.moumita.springboot.Demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="Employee")

public class Employee {

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empname=" + ename + ", gender=" + gender + ", jobrole=" + jobrole
				+ ", salary=" + sal + "]";
	}
	@Id
	@Column
	private int empno;
	@Column
	private String ename;
	@Column
	private String gender;
	@Column
	private String jobrole;
	@Column
	private double sal;
	
	public int getEmpno() {
		return empno;
	}
	
	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmpname() {
		return ename;
	}
	
	public void setEmpname(String empname) {
		this.ename = empname;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getJobrole() {
		return jobrole;
	}
	
	public void setJobrole(String jobrole) {
		this.jobrole = jobrole;
	}
	
	public double getSalary() {
		return sal;
	}
	
	public void setSalary(double salary) {
		this.sal = salary;
	}
	
	
	
}
